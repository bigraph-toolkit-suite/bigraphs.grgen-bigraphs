Solutions of the live contest of the GraBaTs 2008
By Sebastian Buchwald and Moritz Kroll
-------------------------------------------------

To execute our solutions just start GrShell of GrGen.NET v2.0 with
one of the following files:

 - conference.grs:
     The solution of the core assignment without printing the 3008 solutions.
 - conferenceShow.grs:
     The solution of the core assignment writing all valid solutions to the
     file solutions.txt
 - conferenceassignment4.grs:
     Our solution for the extension assignment (Blockables)

So, if the bin folder of GrGen.NET is in your path, type something like the
following at the command prompt:

   GrShell conference
