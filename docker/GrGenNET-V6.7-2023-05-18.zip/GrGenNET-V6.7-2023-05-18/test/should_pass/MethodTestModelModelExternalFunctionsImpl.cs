// This file has been generated automatically by GrGen (www.grgen.net)
// Do not modify this file! Any changes will be lost!
// Generated from "MethodTestModel.gm" on Fri Nov 01 12:07:41 CET 2013

using System;
using System.Collections.Generic;
using System.IO;
using GRGEN_LIBGR = de.unika.ipd.grGen.libGr;
using GRGEN_LGSP = de.unika.ipd.grGen.lgsp;

namespace de.unika.ipd.grGen.expression
{
	using GRGEN_MODEL = de.unika.ipd.grGen.Model_MethodTestModel;

	public partial class ExternalProcedures
	{
		public static void externalProcedure(GRGEN_LIBGR.IActionExecutionEnvironment actionEnv, GRGEN_LIBGR.IGraph graph)
		{
		}
	}
}
