// This file has been generated automatically by GrGen (www.grgen.net)
// Do not modify this file! Any changes will be lost!
// Generated from "multiruleallcallmatchfilterexternal.grg" on 27.02.2020 09:47:22 Mitteleuropäische Zeit
using System;
using System.Collections.Generic;
using GRGEN_LIBGR = de.unika.ipd.grGen.libGr;
using GRGEN_LGSP = de.unika.ipd.grGen.lgsp;
using GRGEN_MODEL = de.unika.ipd.grGen.Model_model;
using GRGEN_ACTIONS = de.unika.ipd.grGen.Action_multiruleallcallmatchfilterexternal;

namespace de.unika.ipd.grGen.Action_multiruleallcallmatchfilterexternal
{
    // ------------------------------------------------------

    public partial class MatchClassFilters
    {
        public static void Filter_shfext(GRGEN_LGSP.LGSPGraphProcessingEnvironment procEnv, IList<GRGEN_LIBGR.IMatch> matches, System.Int32 f)
        {
        }
    }

    // ------------------------------------------------------
}
